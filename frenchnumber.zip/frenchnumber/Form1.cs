namespace frenchnumber;

public partial class Form1 : Form
{
    private static readonly string[] frenchUnits = {
    "zéro", "un", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf",
    "dix", "onze", "douze", "treize", "quatorze", "quinze", "seize",
    "dix-sept", "dix-huit", "dix-neuf"
};

private static readonly string[] frenchTens = {
    "", "", "vingt", "trente", "quarante", "cinquante", "soixante",
    "soixante-dix", "quatre-vingt", "quatre-vingt-dix"
};
    private string FrenchNumberNumberToWords(long number)
    {
        if (number == 0) return frenchUnits[0];
        if (number < 0) return "moins " + FrenchNumberNumberToWords(Math.Abs(number));
        string words = "";
        if (number >= 1_000_000_000_000_000)
        {
            long quadrillions = number / 1_000_000_000_000_000;
            words += FrenchNumberNumberToWords(quadrillions) + " billards";
            number %= 1_000_000_000_000_000;
            if (number > 0) words += "";
        }
        if (number >= 1_000_000_000_000)
        {
            long trillions = number / 1_000_000_000_000;
            words += FrenchNumberNumberToWords(trillions) + " billions";
            number %= 1_000_000_000_000;
            if (number > 0) words += "";
        }
        if (number >= 1_000_000_000)
        {
            long millards = number / 1_000_000_000;
            words += millards == 1 ? "un millard" : FrenchNumberNumberToWords(millards) + " millards";
            number %= 1_000_000_000;
            if (number > 0) words += "";
        }
        if (number >= 1_000_000)
        {
            long millions = number / 1_000_000;
            words += millions == 1 ? "un million" : FrenchNumberNumberToWords(millions) + " millions";
            number %= 1_000_000;
            if (number > 0) words += "";
        }
        if (number >= 1000)
        {
            long thousands = number / 1000;
            if (thousands == 1) words += "mille";
            else words += FrenchNumberNumberToWords(thousands) + " mille";
            number %= 1000;
            if (number > 0) words += "";
        }
        if (number >= 100)
        {
            long hundreds = number / 100;
            if (hundreds == 1) words += "cent";
            else words += frenchUnits[hundreds] + " cent";
            if (number % 100 == 0 && hundreds > 1) words += "s";
            number %= 100;
            if (number > 0) words += "";
        }
        if (number > 0)
        {
            if (number < 20)
            {
                words += frenchUnits[number];
            }
            else
            {
                long ten = number / 10;
                long unit = number % 10;
                if (ten == 7 || ten == 9)
                {
                    words += frenchTens[ten] + "-" + frenchUnits[10 + unit];
                }
                else if (ten == 8 && unit == 0)
                {
                    words += "quatre-vingts";
                }
                else
                {
                    words += frenchTens[ten];
                    if (unit == 1 && ten != 8)
                    {
                        words += " et un";
                    }
                    else if (unit > 0)
                    {
                        words += "-" + frenchUnits[unit];
                    }

                }
            }
            
        }
        return words.Trim();
}
    


    public Form1()
    {
        InitializeComponent();
    }
    private void textBox1_TextChanged(object sender, EventArgs e)
    {
        if (long.TryParse(textBox1.Text, out long number))
        {
            label1.Text = "French : " + FrenchNumberNumberToWords(number);
        }
        else
        {
            label1.Text = "Invalid input";
        }
    }
    

}
